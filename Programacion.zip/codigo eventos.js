const button = document.querySelector(".button");

//button.addEventListener("click",saludar);//agragamos una escucha de evento(evento,funcion a ejecutar)
//
//function saludar(){
//	alert("hola");
//	button.removeEventListener("click",saludar)//una vez que se ejecuta, se remueve y no vuelve a funcionar
//}

button.addEventListener("click",(event)=>{
	console.log(event)
}