let cadena = "cadena de prueba";
let cadena2 = " cadena2";

resultado = cadena.concat(" cadena 2")

document.write(resultado)
