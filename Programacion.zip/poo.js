class Animal {
	constructor (especie,edad,color){
		this.especie = especie; //this.algo es el atributo  prop wque van a tener, tantos años, o tal raza
		this.edad = edad;
		this.color = color
		this.info = `Soy ${this.especie}, tengo ${this.edad} años y soy de color ${this.color}`;
	}
	verInfo(){
	document.write(this.info + "<br>")
	}
	//ladrar(){
	//	if(this.especie == "perro") {
	//		document.write("Waw!" + "<br>");
	//	} else {
	//		document.write("No puede ladrar porque es un " + this.especie + "<br>")
	//	}
	//}
}

class Perro extends Animal { // la clase perro va a contener a la clase Animal, y le va a agregar unas cosas especificas
	constructor (especie,edad,color,raza){ //hereda del constructor, tmb hereda todos los metodos this.(los que nombre entre parentesis)
		this.raza = raza;
	}
}





//cuando se trabaja con obj se pone "const" en vez de "let"
const perro = new Perro("perro",5,"rojo","caniche"); //perro es un objeto de la clase Animal
const gato = new Animal("gato",2,"negro"); 
const pajaro = new Animal("pajaro",1,"verde"); 

//document.write(perro.info + "<br>")
//document.write(gato.info + "<br>")
//document.write(pajaro.info + "<br>")

perro.verInfo();
gato.verInfo();
pajaro.verInfo();


//perro.ladrar();
//gato.ladrar();
//pajaro.ladrar();
//los 3 objetos se comportan distintos ante la misma funcion, eso es polimorfismo