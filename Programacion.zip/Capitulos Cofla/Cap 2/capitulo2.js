
//CAPITULO 2
//A. Mayores de 18 pueden pasar, y primer pwersona despues de las 2 am pasa gratis:

//let free = false; //defino la variable free

//const validarCliente = (time)=>{
//	let edad = prompt ("cual es tu edad?");//pregunto para dar valor a edad
//	if (edad > 18) { // si edad es mayor a 18
//		if (time >= 2 && time < 7 && free == false) {
//		// si entra despes de las 2 y antes de las 7, y frre es false
//			alert("podes pasar gratis");
//			free=true;
//		} else { //de lo contrario..
//			alert (`Son las ${time}:00Hs Podes pasar, pero tenes que pagar`);
//		}
//
//	}	else {
//		alert ("No podes pasar");
//	}
//}
//validarCliente(23);
//validarCliente(24);
//validarCliente(0.2);
//validarCliente(0.6);
//validarCliente(1);
//validarCliente(2);


//B. Crear mini sistema para registrar a los alumnos presentes y ausentes, 
//pasado los 30 dias mostrar la sit de cada uno (nro de presentes y ausentes)
//se puede tener maximo 10% de ausencias por semestre, si tiene mas esta desaprobado.

let cantidad = prompt("cuantos alumnos son?");
let alumnosTotales = []; //aray

for (i = 0; i < cantidad; i++) { // i se va a ejecutar mientras sea menor que cantidad, y lo vamso a incrementar
	alumnosTotales[i] = [prompt("Nombre del alumno " + (i+1)),0];
}

const tomarAsistencia = (nombre,p)=>{ //Nos va a pedir el nombre, y la posicion en la lista
	let presencia = prompt(nombre); //le vamos a dar opcion de marcar P o A
	if (presencia == "p" || presencia == "P") { //dar opcion minuscula y mayuscula para que funcione sin importar como lo escriba
		alumnosTotales[p][1]++;//acceso al primer arry (alumnosTotales) y despues al 2do arry que esta dentro del 1ero (posicion)
	}
}


for (i = 0; i < 30; i++) { //vamos a ejecutar 30 veces el bucle (tomar asistencia 30 dias)
	for (alumno in alumnosTotales) { //for in, nos da la posicion de cada alumno
	tomarAsistencia(alumnosTotales[alumno][0],alumno);
	}
}

//sit final de todos los alumnos
for (alumno in alumnosTotales) {
	let resultado = `${alumnosTotales[alumno][0]}:<br>
	_____Presencias: ${alumnosTotales[alumno][1]} <br>
	_____Ausencias: ${30 - parseInt(alumnosTotales[alumno][1])}
	`;

	if (30 - alumnosTotales[alumno][1] > 18) { //si las ausencias son mayores a 18 dias (mas del 50% del mes)
 		resultado+= "REPROBADO POR INASISTENCIAS<br><br>";
	} else {
		resultado+= "<br><br>";
	}
	document.write(resultado)
}