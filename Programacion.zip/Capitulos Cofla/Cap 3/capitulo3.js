//A) ver caracteristias de celulares
	//class celular {
	//	constructor(color,peso,tamaño,rdc,ram){
	//		this.color = color;
	//		this.peso = peso;
	//		this.tamaño = tamaño;
	//		this.resolucionDeCamara = rdc;
	//		this.memoriaRam = ram;
	//		this.encendido = false;
	//	}
	
		//prender(){
		//	if (this.encendido == false) {
		//		alert ("celular prendiendo");
		//		this.encendido = true;
		//	} else {
		//		alert("el celular ya esta encendido")		
		//	}
		//}

		//apagar(){
		//	if (this.encendido == true) {
		//		alert ("celular apagando");
		//		this.encendido = false;
		//	} else {
		//		alert("el celular ya esta apagado")
		//	}
		//}

	//	presionarBotonEncendido(){ //resumiendo el prender y apagar en 1 sola funcion
	//		if (this.encendido == false) {
	//			alert ("celular prendido");
	//			this.encendido = true;
	//		} else {
	//			alert("celular apagado");
	//			this.encendido = false;
	//		}
	//	}

	//	reiniciar(){
	//		if (this.encendido == true) {
	//			alert ("celular reiniciando");
	//		} else {
	//			alert("el celular esta apagado");
	//		}
	//	}

	//	tomarFoto(){
	//		alert(`foto tomada en una resolucion de: ${this.resolucionDeCamara}`);
	//	}

	//	grabarVideos(){
	//		alert(`grabando video en: ${this.resolucionDeCamara}`);
	//	}

	//	mobileInfo(){
	//		return `
	//		Color: <b>${this.color}</b></br>
	//		Peso: <b>${this.peso}</b></br>
	//		Tamaño: <b>${this.tamaño}</b></br>
	//		Resolucion de Video: <b>${this.resolucionDeCamara}</b></br>
	//		Memoria Ram: <b>${this.memoriaRam}</b></br>
	//		`;
	//	}
	//}


	//class CelularAltaGama extends celular {
	//	constructor(color,peso,tamaño,rdc,ram,rdce){
	//		super(color,peso,tamaño,rdc,ram);
	//		this.resolucionDeCamaraExtra = rdce;
	//	}
	//	grabarVideoLento(){
	//		alert("estas grabando en camara lenta");
	//	}
	//	reconocimientoFacial(){
	//		alert("vamos a iniciar el reconocimiento facial");

//B)analizar celulares de alta gama
	//	}
	//	infoAltaGama(){
	//		return this.mobileInfo() + `Resolucion de Camara Extra: ${this.resolucionDeCamaraExtra}`;
	//	}
	//}


	//celular1 = new celular("rojo","150g","5'","hd","1GB");
	//celular2 = new celular("negro","155g","5.4'","full hd","2GB");
	//celular3 = new celular("blanco","146g","5.9'","full hd","2GB");

	//celular1.tomarFoto()
	//celular1.grabarVideos()
	//celular1.reiniciar()
	//celular1.presionarBotonEncendido()



	//celular1 = new CelularAltaGama("rojo","150g","5'","hd","1GB","full hd");
	//celular2 = new CelularAltaGama("negro","155g","5.4'","full hd","2GB","hd");
	//celular3 = new CelularAltaGama("blanco","146g","5.9'","full hd","2GB");


	//document.write(`
	//	${celular1.infoAltaGama()} <br><br>
	//	${celular2.infoAltaGama()} <br><br>
	//	${celular3.infoAltaGama()} <br>
	//	`);


//C) poder abrir cerrar instalar y desinstalar apps
class App {
	constructor(descargas,puntuacion,peso){
		this.descargas = descargas;
		this.puntuacion = puntuacion;
		this.peso = peso;
		this.iniciada = false;
		this.instalada = false;
	}
	
	instalar(){
		if (this.instalada == false) {
			this.instalada = true;
			alert("app instalada correctamente");
		}
	}
	desinstalar(){
		if (this.desinstalada = true) {
			this.desinstalada = false;	
			alert("app desinstalada correctamente");
		}
	}

	abrir(){
		if (this.iniciada == false && this.instalada == true) {
			this.iniciada = true;
			alert("app encendida");
		}
	}
	cerrar(){
		if (this.iniciada == true && this.instalada == true) {
			this.iniciada = false;
			alert("app cerrada");
		}
	}
	appInfo(){
		return `
		Descargas: <b>${this.descargas}</b></br>
		Puntuacion: <b>${this.puntuacion}</b></br>
		Peso: <b>${this.peso}</b></br>
		`
	}
}


//pasa en el orden que lo pongo aca abajo
	//app.instalar();
	//app.abrir();
	//app.cerrar();
	//app.desinstalar();

app1 = new App("16.000","5 estrellas","900mb");
app2 = new App("1.000","4 estrellas","400mb");
app3 = new App("6.000","4.5 estrellas","100mb");
app4 = new App("23.000","4.8 estrellas","1gb");
app5 = new App("900","5 estrellas","250mb");
app6 = new App("17","3.7 estrellas","522mb");
app7 = new App("42.000","2.9 estrellas","723mb");

document.write(`
	${app1.appInfo()} <br>
	${app2.appInfo()} <br>
	${app3.appInfo()} <br>
	${app4.appInfo()} <br>
	${app5.appInfo()} <br>
	${app6.appInfo()} <br>
	${app7.appInfo()} <br>
	`);