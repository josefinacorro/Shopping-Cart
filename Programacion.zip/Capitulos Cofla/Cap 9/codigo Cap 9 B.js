alumno = [{
	nombre: "Josefina Corro",
	email: "josefionacorro@gmail.com",
	materia: "Taller 3"
},{
	nombre: "Crostobal Gerez",
	email: "gerezcristobal@gmail.com",
	materia: "Fluidos"
},{
	nombre: "Lucas Dalto",
	email: "lucasdalto@gmail.com",
	materia: "Fisica 1"
},{
	nombre: "Coffla XD",
	email: "coffla@gmail.com",
	materia: "Dibujo 2"
}]


for (alumno in alumnos){
	console.log(alomnos[alumno])
}