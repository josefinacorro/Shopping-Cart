dineroCofla = prompt("cuanto dinero tienes Cofla?");
dineroRoberto = prompt("cuanto dinero tienes Roberto?");
dineroPedro = prompt("cuanto dinero tienes Pedro?");

if (dineroCofla > 0.6 && dineroCofla < 1) {
	alert("Cofla; comprate el helado de agua")
}

else if (dineroCofla > 1 && dineroCofla < 1.6) {
	alert("Cofla; comprate el helado de crema")
}

else if (dineroCofla > 1.6 && dineroCofla < 1.7) {
	alert("Cofla; comprate el helado de ddl")
}

else if (dineroCofla > 1.7 && dineroCofla < 1.8) {
	alert("Cofla; comprate el helado de choco")
}

else if (dineroCofla > 1.8 && dineroCofla < 2.9) {
	alert("Cofla; comprate el helado de limon")
}

else if (dineroCofla >= 2.0) {
	alert("Cofla; comprate el helado de frutilla o el pote de 1/4Kg");
} else {
	alert("Cofla; no te alcanza para ninguno")
}


if (dineroRoberto > 0.6 && dineroRoberto < 1) {
	alert("Roberto; comprate el helado de agua")
}

else if (dineroRoberto > 1 && dineroRoberto < 1.6) {
	alert("Roberto; comprate el helado de crema")
}

else if (dineroRoberto > 1.6 && dineroRoberto < 1.7) {
	alert("Roberto; comprate el helado de ddl")
}

else if (dineroRoberto > 1.7 && dineroRoberto < 1.8) {
	alert("Roberto; comprate el helado de choco")
}

else if (dineroRoberto > 1.8 && dineroRoberto < 2.9) {
	alert("Roberto; comprate el helado de limon")
}

else if (dineroRoberto >= 2.0) {
	alert("Roberto; comprate el helado de frutilla o el pote de 1/4Kg");
} else {
	alert("Roberto; no te alcanza para ninguno")
}


if (dineroPedro > 0.6 && dineroPedro < 1) {
	alert("Pedro; comprate el helado de agua")
}

if (dineroPedro > 1 && dineroPedro < 1.6) {
	alert("Pedro; comprate el helado de crema")
}

else if (dineroPedro > 1.6 && dineroPedro < 1.7) {
	alert("Pedro; comprate el helado de ddl")
}

else if (dineroPedro > 1.7 && dineroPedro < 1.8) {
	alert("Pedro; comprate el helado de choco")
}

else if (dineroPedro > 1.8 && dineroPedro < 2.9) {
	alert("Pedro; comprate el helado de limon")
}

else if (dineroPedro >= 2.0) {
	alert("Pedro; comprate el helado de frutilla o el pote de 1/4Kg");
} else {
	alert("Pedro; no te alcanza para ninguno")
}