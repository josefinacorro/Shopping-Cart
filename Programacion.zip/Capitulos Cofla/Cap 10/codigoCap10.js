const sendButton = document.getElementById('send-nota');

sendButton.addEventListener("click",()=>{
	let resultado,mensaje;
	try {
		resultado = parseInt(document.getElementById('nota').value);
		if (isNaN(resultado)) {
			throw "Gracioso";
		}
		mensaje = "Hola";
	} catch(e){
		resultado = "Sos gracioso?";
		mensaje = "intentaste hackear el sitio";
	}
	abrirModal(resultado,mensaje);
})

const abrirModal = (res,msj)=>{
	console.log(res);
	console.log(msj);
}